#Direction Tracker
#
##The music used includes：
####Kan R. Gao - To the Moon - Piano (Ending Version)
#
####Staff Roll - (Game: Rabiribi)
#
####Hall of Memory - (Game: Rabiribi)
#
##Special Instruction:
####1. Press 'Esc' on the Game or Help page will return to the Title immediately.
####2. Three Lives.
#
##Ps
###At this stage, the game only realizes the basic functions. And there are still many deficiencies. We may optimize it in the future.
#
###Thanks for playing.