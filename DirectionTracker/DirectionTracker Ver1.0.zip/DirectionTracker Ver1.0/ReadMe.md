#Direction Tracker
#
##The music used includes：
####Kan R. Gao - To the Moon - Piano (Ending Version)
#
####Staff Roll - (Game: Rabiribi)
#
####Hall of Memory - (Game: Rabiribi)
#
##Special Instruction:
####1. Press 'Esc' on the Game will show the PauseMenu immediately.
####2. Three Lives.
#
##Ps
###At this stage, the game only realizes the basic functions. And there are still many deficiencies. I may optimize it in the future.
#
###Thanks for playing.